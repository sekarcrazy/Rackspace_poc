(function() {
  exports.selectOptionByText = function(element, item) {
    var desiredOption;
    desiredOption = null;
    return element.findElements(by.tagName('option')).then(function(options) {
      return options.some(function(option) {
        option.getText().then(function(text) {
          if (item === text) {
            desiredOption = option;
            return true;
          }
        });
      });
    }).then(function() {
      if (desiredOption) {
        return desiredOption.click();
      }
    });
  };

}).call(this);
