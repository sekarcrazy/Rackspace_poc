(function() {
  describe('newton inventory page', function() {
    var httpBackend, mockFastProvisionData, mockInventoryData, newtonInventoryPage, page, provisioningUrl, setUpMocks;
    page = require('./pages/NewtonInventoryPage.js');
    httpBackend = require('http-backend-proxy');
    mockFastProvisionData = require('./data/fastprovision.json');
    mockInventoryData = require('./data/inventory.json');
    newtonInventoryPage = new page();
    setUpMocks = function(config) {
      var proxy, rc_enabled_response;
      proxy = new httpBackend(browser);
      proxy.onLoad.reset();
      proxy.onLoad.whenGET('/newton/v1/inventory').respond(200, mockInventoryData);
      proxy.onLoad.whenGET('/newton/v1/ibase/account/1234').respond(200, mockFastProvisionData);
      proxy.onLoad.whenGET('/newton/v1/ibase/account/4321').respond(200, {
        "is_fast_provision": false
      });
      proxy.onLoad.whenGET('/newton/v1/core/account_status/4567').respond(200, {
        "is_new": true
      });
      proxy.onLoad.whenGET('/newton/v1/core/account_status/1234').respond(200, {
        "is_new": false
      });
      if (config.is_rc_enabled) {
        rc_enabled_response = {
          is_active: true,
          feature_data: {
            allowed_datacenters: ["IAD3"]
          }
        };
        proxy.onLoad.whenGET('/newton/v1/feature_status/RackConnect').respond(200, rc_enabled_response);
      } else {
        proxy.onLoad.whenGET('/newton/v1/feature_status/RackConnect').respond(200, {
          is_active: false
        });
      }
      proxy.onLoad.whenGET(/.*/).passThrough();
      return proxy;
    };
    provisioningUrl = function(dc, aggrZone) {
      return 'http://localhost:9005/control-panel/index.html#/provision/datacenter/' + dc + '/aggrzone/' + aggrZone;
    };
    describe('Account type validation', function() {
      beforeEach(function() {
        setUpMocks({
          is_rc_enabled: true
        });
        browser.driver.manage().window().maximize();
        return newtonInventoryPage.home();
      });
      
    });
    describe('Inventory display and firewall selections when rackconnect is enabled', function() {
      var filterBy, filterByOptions, _fn, _i, _len;
      beforeEach(function() {
        setUpMocks({
          is_rc_enabled: true
        });
        browser.driver.manage().window().maximize();
        return newtonInventoryPage.home();
      });
      
      filterByOptions = ['FIREWALL'];
      _fn = function(filterOption) {
        return it('valid existing account type displays inventory as expected for filter ' + filterOption, function() {
          newtonInventoryPage.getInventoryForAccount('1234', 'existing');
          switch (filterOption) {
            case "DC":
              newtonInventoryPage.chooseDCFilter().selectDataCenterByText('IAD3');
              break;
            case "FIREWALL":
              newtonInventoryPage.chooseFirewallFilter().selectFirewallByText('620463');
          }
          expect(newtonInventoryPage.getHeaderTitle()).toBe('IAD3 Inventory');
          expect(newtonInventoryPage.aggrZonesCount()).toBe(2);
          newtonInventoryPage.withAggrZone('IAD3:Public:Zone403-11');
          expect(newtonInventoryPage.getAggrZoneTitle()).toBe('IAD3:Public:Zone403-11');
          if (filterOption === "DC") {
            expect(newtonInventoryPage.isFirewallSelectionDisplayed()).toBe(true);
            return newtonInventoryPage.getAvailableFirewallsForSelection().then(function(firewalls) {
              var j, _j;
              expect(firewalls.length).toBe(3);
              expect(firewalls[0].getText()).toBe('620463 - 620463-TestRBA.TestRBA.com');
              expect(firewalls[1].getText()).toBe('620464 - 620464-TestRBA.TestRBA.com');
              expect(firewalls[2].getText()).toBe('New Firewall');
              expect(newtonInventoryPage.isRackConenctQuestionVisible()).toBe(false);
              for (j = _j = 0; _j <= 2; j = ++_j) {
                firewalls[0].click();
                expect(newtonInventoryPage.getAggrZoneDevicesCount()).toBe(5);
                firewalls[2].click();
                expect(newtonInventoryPage.getAggrZoneDevicesCount()).toBe(6);
                expect(newtonInventoryPage.isRackConenctQuestionVisible()).toBe(true);
              }
              firewalls[2].click();
              expect(newtonInventoryPage.isRackConenctQuestionVisible()).toBe(true);
              newtonInventoryPage.chooseRackConnect();
              expect(newtonInventoryPage.getAggrZoneDevicesCount()).toBe(1);
              newtonInventoryPage.provisionHere();
              return expect(browser.getCurrentUrl()).toMatch(provisioningUrl('IAD3', 'IAD3:Public:Zone403-11'));
            });
          } else {
            expect(newtonInventoryPage.isFirewallSelectionAvailable()).toBe(false);
            return newtonInventoryPage.getAvailableFirewallsForSelectionByFWFilter().then(function(firewalls) {
              expect(firewalls.length).toBe(1);
              expect(newtonInventoryPage.getSelectedFWTextPassByElement(firewalls[0])).toBe('620463 - 620463-TestRBA.TestRBA.com');
			  
              expect(newtonInventoryPage.getAggrZoneDevicesCount()).toBe(5);
              newtonInventoryPage.provisionHere();
              return expect(browser.getCurrentUrl()).toMatch(provisioningUrl('IAD3', 'IAD3:Public:Zone403-11'));
            });
          }
        });
      };
      for (_i = 0, _len = filterByOptions.length; _i < _len; _i++) {
        filterBy = filterByOptions[_i];
        _fn(filterBy);
      }      
    });
  });

}).call(this);
