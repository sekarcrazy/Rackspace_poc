(function() {
  var NewtonInventoryPage;

  NewtonInventoryPage = (function() {
    function NewtonInventoryPage() {
      this.dc = element(by.model('selectedDc'));
      this.firewall = element(by.model('selectedFirewall'));
      this.accountOptions = element.all(by.name('accountType'));
      this.filterOptions = element.all(by.name('filterBy'));
      this.accountId = element(by.name('accountId'));
      this.selectedDataCenter = element(by.selectedOption('selectedDc'));
      this.aggrZonesInventory = element.all(by.repeater("data in dcInventory | orderBy:'aggr_zone' | filter: dcAggrFilter"));
      this.servers = element.all(by.repeater('item in aggrDevices | orderBy:sort.column:sort.descending'));
      this.getInventoryButton = element(by.buttonText('Get Inventory'));
      this.headerTitle = $('.rs-detail-header-title');
      this.firewallSelections = element.all(by.repeater('firewall in installbase_data[data.aggr_zone].firewalls_selection'));
      this.aggrZoneTitles = element.all(by.binding('data.aggr_zone'));
      this.errorMessage = element(by.css('.rs-validation-block'));
      this.aggrZoneBeingValidated = null;
      this.goToSummaryButton = element(by.buttonText('Go to summary'));
      this.rackconnect = element.all(by.name('rackconnect'));
      this.rackconnectQuestion = element(by.name('rcv3_question'));
    }

    NewtonInventoryPage.prototype.home = function() {
      browser.get('http://localhost:9005/control-panel/index.html#/inventory?sample');
      browser.driver.manage().window().maximize();
      return this;
    };

    NewtonInventoryPage.prototype.getInventoryForAccount = function(id, type) {
      var accountIndex;
      accountIndex = type === 'new' ? 0 : 1;
      this.accountOptions.get(accountIndex).click();
      this.accountId.sendKeys(id);
      return this.getInventory();
    };

    NewtonInventoryPage.prototype.chooseNewAccountType = function() {
      this.accountOptions.get(0).click();
      return this;
    };

    NewtonInventoryPage.prototype.chooseExistingAccountType = function() {
      this.accountOptions.get(1).click();
      return this;
    };

    NewtonInventoryPage.prototype.isGoToSummaryLinkAvailable = function() {
      return this.goToSummaryButton.isDisplayed();
    };

    NewtonInventoryPage.prototype.goToSummary = function() {
      return this.goToSummaryButton.click();
    };

    NewtonInventoryPage.prototype.chooseFirewallFilter = function() {
      this.filterOptions.get(0).click();
      return this;
    };

    NewtonInventoryPage.prototype.chooseDCFilter = function() {
      this.filterOptions.get(1).click();
      return this;
    };

    NewtonInventoryPage.prototype.get = function(dc, aggrZone) {
      return this.selectDataCenterByText(dc).provisionHere();
    };

    NewtonInventoryPage.prototype.selectDataCenter = function(optionNum) {
      var options;
      if (optionNum) {
        return options = this.dc.findElements(by.tagName('option')).then(function(options) {
          return options[optionNum].click();
        });
      }
    };

    NewtonInventoryPage.prototype.isDCSelectionAvailable = function() {
      return this.dc.isDisplayed();
    };

    NewtonInventoryPage.prototype.selectFirewall = function(firewall) {
      var firewallElement;
      firewallElement = element(by.name("firewall_" + firewall));
      firewallElement.click();
      return this;
    };

    NewtonInventoryPage.prototype.selectDataCenterByText = function(optionText) {
      protractor.locators.selectOptionByText(this.dc, optionText);
      return this;
    };

    NewtonInventoryPage.prototype.selectFirewallByText = function(optionText) {
      protractor.locators.selectOptionByText(this.firewall, optionText);
      return this;
    };

    NewtonInventoryPage.prototype.getErrorMessage = function() {
      return this.errorMessage.getText();
    };

    NewtonInventoryPage.prototype.getDataCenterText = function(optionNum) {
      this.selectDataCenter(optionNum);
      return this.selectedDataCenter.getText();
    };

    NewtonInventoryPage.prototype.getSelectedDataCenter = function() {
      return this.selectedDataCenter.getText();
    };

    NewtonInventoryPage.prototype.getInventory = function() {
      this.getInventoryButton.click();
      return this;
    };

    NewtonInventoryPage.prototype.provisionHere = function(aggrZoneBeingValidated) {
      return this.aggrZoneBeingValidated.findElement(by.buttonText('Provision Here')).click();
    };

    NewtonInventoryPage.prototype.getAggrZoneTitle = function() {
      return this.aggrZoneBeingValidated.findElement(by.binding('data.aggr_zone')).getText();
    };

    NewtonInventoryPage.prototype.isRackConenctQuestionVisible = function() {
      return this.aggrZoneBeingValidated.findElement(by.model('data.rackconnect_user_choice')).isDisplayed();
    };

    NewtonInventoryPage.prototype.withAggrZone = function(aggrZoneName) {
      this.aggrZoneBeingValidated = element(by.name(aggrZoneName + '_section'));
      return this;
    };

	NewtonInventoryPage.prototype.isFirewallSelectionAvailable = function() {
      return this.aggrZoneBeingValidated.findElement(by.name('choose-firewall')).then(function(firewall) {
        return true;
      }, function(error){
		  return false;
	  });
    };
	
    NewtonInventoryPage.prototype.isFirewallSelectionDisplayed = function() {
      return this.aggrZoneBeingValidated.findElement(by.name('choose-firewall')).isDisplayed();
    };

    NewtonInventoryPage.prototype.getAvailableFirewallsForSelection = function() {
      return this.aggrZoneBeingValidated.findElements(by.repeater("firewall in installbase_data[data.aggr_zone].firewalls_selection"));
    };

    NewtonInventoryPage.prototype.getSelectedFWTextPassByElement = function(parentElement) {
      return parentElement.findElement(by.css('h3')).then(function(fw) {
        return fw.getText();
      });
    };

    NewtonInventoryPage.prototype.getAvailableFirewallsForSelectionByFWFilter = function() {
      return this.aggrZoneBeingValidated.findElements(by.repeater("firewall in installbase_data[data.aggr_zone].firewalls_selection | filter:{ fw_device: installbase_data[data.aggr_zone].selected_firewall_device_id }"));
    };

    NewtonInventoryPage.prototype.selectFirewallByDeviceId = function(firewallDeviceId) {
      this.aggrZoneBeingValidated.findElement(by.name("firewall_" + firewallDeviceId)).click();
      return this;
    };

    NewtonInventoryPage.prototype.aggrZonesCount = function() {
      return this.aggrZonesInventory.count().then(function(count) {
        return count;
      });
    };

    NewtonInventoryPage.prototype.getAggrZoneDevicesCount = function() {
      return this.aggrZoneBeingValidated.findElements(by.repeater("details in data.devices | orderBy:['device_type', sort.column]:sort.descending")).then(function(devices) {
        return devices.length;
      });
    };

    NewtonInventoryPage.prototype.getHeaderTitle = function() {
      return this.headerTitle.getText().then(function(text) {
        return text.trim();
      });
    };

    NewtonInventoryPage.prototype.chooseRackConnect = function() {
      this.aggrZoneBeingValidated.findElement(by.model('data.rackconnect_user_choice')).click();
      return this;
    };

    NewtonInventoryPage.prototype.rejectRackConnect = function() {
      this.aggrZoneBeingValidated.findElement(by.model('data.rackconnect_user_choice')).click();
      return this;
    };

    return NewtonInventoryPage;

  })();

  module.exports = NewtonInventoryPage;

}).call(this);
