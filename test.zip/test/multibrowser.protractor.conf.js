// An example configuration file.
exports.config = {
  // Do not start a Selenium Standalone sever - only run this using chrome.
  seleniumAddress: 'http://localhost:4444/wd/hub',

  multiCapabilities: [
      {'browserName': 'firefox'},
      {
          'browserName': 'chrome',
          'chromeOptions': {
              'args': ['show-fps-counter=true', 'enable-preparsed-js-caching', 'enable-devtools-experiments', 'enable-precache', 'enable-profiling'],
              'extensions': []
          }
      }
  ],

  baseUrl: 'http://localhost/control-panel/',

  // Spec patterns are relative to the current working directly when
  // protractor is called.
  specs: ['./e2e/generated/*Spec.js'],

  // Options to be passed to Jasmine-node.
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000
  }
};
