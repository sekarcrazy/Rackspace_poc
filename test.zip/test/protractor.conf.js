// An example configuration file.
exports.config = {
  directConnect: true,

  // Capabilities to be passed to the webdriver instance.
  capabilities: {
    'browserName': 'chrome'
  },

  baseUrl: 'http://localhost:9008/control-panel/',

  // Spec patterns are relative to the current working directly when
  // protractor is called.
  specs: ['./e2e/generated/*.js'],

  // Options to be passed to Jasmine-node.
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000
  },
  onPrepare: function () {
    protractor.locators = require('./e2e/generated/helpers/Locators.js');
    var HtmlReporter = require('protractor-html-screenshot-reporter');
    // Add a screenshot reporter and store screenshots to `/tmp/screnshots`:
    jasmine.getEnv().addReporter(new HtmlReporter({
        baseDirectory: '../../protractor-reports',
        takeScreenShotsOnlyForFailedSpecs: true,
        pathBuilder: function pathBuilder(spec, descriptions, results, capabilities) {
          // Return '<browser>/<specname>' as path for screenshots:
          // Example: 'firefox/list-should work'.
          return descriptions.join('-').substring(0,250); //to account for ENAMETOOLONG error, truncate the filename
        }
    }));
  }
};
