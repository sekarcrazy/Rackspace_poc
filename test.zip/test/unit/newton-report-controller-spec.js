describe('newtonReport', function () {
    var $rootScope,
        $scope,
        $httpBackend,
        controller;

    beforeEach(function () {
        module('newton.controllers');
        module('newton.services');

        inject(function ($injector, _$httpBackend_) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            $httpBackend = _$httpBackend_;
            $httpBackend
                .whenGET('/newton/v1/automation/report/rackspace')
                .respond({
                    'thresholds': {
                        'IAD3_Rackspace Dedicated Server - One': {'critical': '21', 'warning': '31'},
                        'IAD3_Rackspace Dedicated Server - Two': {'critical': '22', 'warning': '32'},
                        'IAD3_Rackspace Dedicated Server - Three': {'critical': '23', 'warning': '33'},
                        'default-default': {'critical': '24', 'warning': '34'}
                    },
                    rackspace: {servers: 'fooBarServer', firewalls: 'fooBarFirewall', datacenters: 'fooBarDatacenter'}
                });
            controller = $injector.get('$controller')('newtonReport', {$scope: $scope});
            // The report is loaded when the controller is initiated. To get a response back from the http we need to flush the request.
            $httpBackend.flush();
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    all("isActiveTab",
        [
            [ "Servers", 0, "active" ],
            [ "Servers", 1, undefined ],
            [ "Firewalls", 1, "active" ],
            [ "Firewalls", 0, undefined ]
        ],
        function (tabName, index, result) {
            $scope.tabs.index = index;
            expect($scope.isActiveTab(tabName)).toBe(result);
        }
    );

    all("get critical and warning thresholds",
        [
            [ '0', undefined, undefined, {'id': '12345'}, '50', '500' ],
            [ '1', undefined, undefined, {'id': 'NonExistentProduct'}, '50', '500' ],
            [ '2', {'name': 'NE-DC'}, undefined, {'id': '12345'}, '50', '500' ],
            [ '3', {'name': 'IAD3'}, undefined, {'id': '12345'}, '40', '400' ],
            [ '4', {'name': 'IAD3'}, undefined, {'id': 'NE-Product'}, '50', '500' ],
            [ '5', {'name': 'IAD3'}, undefined, {'id': '12345'}, '40', '400' ],
            [ '6', {'name': 'IAD3'}, undefined, {'id': 'NE-Product'}, '50', '500' ],
            [ '7', {'name': 'IAD3'}, {'name': 'NE-Zone'}, {'id': '12345'}, '50', '500' ],
            [ '8', {'name': 'IAD3'}, {'name': 'Zone-1'}, {'id': 'NE-Prod'}, '50', '500' ],
            [ '9', {'name': 'IAD3'}, {'name': 'Zone-1'}, {'id': '12345'}, '10', '100' ],
            [ '10', {'name': 'IAD3'}, {'name': 'Zone-2'}, {'id': '12345'}, '20', '200' ],
            [ '11', {'name': 'IAD3'}, {'name': 'Zone-3'}, {'id': '12345'}, '30', '300' ],
            [ '12', {'name': 'NE-DC'}, {'name': 'Zone-1'}, {'id': '12345'}, '50', '500' ],
            [ '13', undefined, {'name': 'Zone-3'}, {'id': '12345'}, '50', '500' ],
            [ '14', {'name': 'IAD3'}, undefined, {'id': '12345'}, '40', '400' ],
            [ '15', {'name': 'IAD3'}, {'name': 'Zone-3'}, undefined, '50', '500' ]
        ],
        function (caseNumber, dc, zone, productId, expectedCriticalThreshold, expectedWarningThreshold) {
            // setup
            $scope.thresholds = {
                'IAD3_Zone-1_12345': {'critical': '10', 'warning': '100'},
                'IAD3_Zone-2_12345': {'critical': '20', 'warning': '200'},
                'IAD3_Zone-3_12345': {'critical': '30', 'warning': '300'},
                'IAD3_default_12345': {'critical': '40', 'warning': '400'},
                'default_default_default': {'critical': '50', 'warning': '500'}
            };
            $scope.datacenter = dc;
            $scope.aggrzone = zone;

            //Expect
            expect($scope.getWarningThreshold(productId)).toBe(expectedWarningThreshold);
            expect($scope.getCriticalThreshold(productId)).toBe(expectedCriticalThreshold);
            // Cleanup
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        }
    );
});