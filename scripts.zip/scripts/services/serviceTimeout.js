(function() {

    'use strict';

    angular.module('scbPinApp')
        .factory('serviceTimeout', serviceTimeout);

    /* @ngInject */
    function serviceTimeout($interval, scbPinAppConfig, cardsListService) {
        var promise;
        var cnt = 0;
        var timeOutSec = scbPinAppConfig.mockTimeoutSec;
        var parent;
        return {
            // plain decode
            startTimer: function() {
                parent = this;
                // stops any running interval to avoid two intervals running at the same time
                this.stopTimer();
                // store the interval promise
                promise = $interval(this.showTimeoutModal, 1000);
            },

            stopTimer: function() {
                cnt = 0;
                $interval.cancel(promise);
            },

            showTimeoutModal: function() {
                cnt++;
                if (cnt === timeOutSec) {
                    parent.timeoutParentFun();
                }
                //on actual timeout redirect page to login URL
                if (cnt === scbPinAppConfig.actualTimeoutSec) {
                   parent.stopTimer();
                   cardsListService.invalidateSession();
                }
            }
        }

    }

})();
