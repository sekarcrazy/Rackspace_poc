/**
 * Created by Supriya on 12/8/16.
 */
(function() {
    'use strict';
    angular.module('scbPinApp').factory('cardsListService', ['$http','$q','scbPinAppConfig','ScbPinNot', function($http, $q,scbPinAppConfig,ScbPinNot) {

        return {
            getCardsList: function(_loader) {
                return ($http({
                    method: scbPinAppConfig.webServices['cardList'].method,
                    url: scbPinAppConfig.webServices['cardList'].url,
                    withCredentials:true,
                    headers: {
                       'Accept': 'application/vnd.api+json'
                    }
                }).then(function(response) {
                    var respAttr = response.data.data[0].attributes;
                    if(respAttr.statusCd!=null && respAttr.statusCd=="0000"){
                        return(response.data);
                    }else{
                        var error = new ScbPinNot(respAttr.errorCd, 'error', true, scbPinAppConfig.navLogout(respAttr.errorCd));
                        error.show();
                        return respAttr.errorCd;
                    }

                }, function(errResp) {
                    var error = new ScbPinNot(errResp.data.errors[0].code, 'error', true, scbPinAppConfig.navLogout(errResp.data.errors[0].code));
                    error.show();
                    return ($q.reject(errResp.data.errors[0].code));
                }).finally(function(error) {
                    return error;
                }));
            },
            submitOTP:function (_data){
                scbPinAppConfig.showLoader = true;
                return ($http({
                    method: scbPinAppConfig.webServices['generateOTP'].method,
                    url: scbPinAppConfig.webServices['generateOTP'].url,
                    withCredentials:true,
                    data:_data,
                    headers: {
                       'Accept': 'application/vnd.api+json'
                    }
                }).then(function(response) {
                    //console.debug(response);
                    var respAttr = response.data.data.attributes;
                    if(respAttr.statusCd!=null && respAttr.statusCd=="0000"){
                        return respAttr;
                    }else{
                        var error = new ScbPinNot(respAttr.errorCd, 'error', true, scbPinAppConfig.navLogout(respAttr.errorCd));
                        error.show();
                        return respAttr.errorCd;
                    }
                }, function(errResp) {
                    var error = new ScbPinNot(errResp.data.errors[0].code, 'error', true, scbPinAppConfig.navLogout(errResp.data.errors[0].code));
                    error.show();
                    return ($q.reject(errResp.data.errors[0].code));
                }).finally(function(error) {
                    return error;
                }));
            },
            resetBySMS:function (_data){
                scbPinAppConfig.showLoader = true;
                return ($http({
                    method: scbPinAppConfig.webServices['smsReset'].method,
                    url: scbPinAppConfig.webServices['smsReset'].url,
                    withCredentials:true,
                    data:_data,
                    headers: {
                       'Accept': 'application/vnd.api+json'
                    }
                }).then(function(response) {
                    var respAttr = response.data.data.attributes;
                    if(respAttr.statusCd!=null && respAttr.statusCd=="0000"){
                        return respAttr;
                    }else{
                        if(respAttr.errorCd=="1505" || respAttr.errorCd=="1507" ){}
                        else{
                            var error = new ScbPinNot(respAttr.errorCd, 'error', true, scbPinAppConfig.navLogout(respAttr.errorCd));
                            error.show();
                        }
                        return respAttr;
                    }
                }, function(errResp) {
                    var _errCd = errResp.data.errors[0].code;
                    console.log("Error Code ", _errCd);
                    if(_errCd=="1508"||_errCd=="1509"||_errCd=="0010"||_errCd=="0008"||_errCd=="0014"){
                    }else{
                      var error = new ScbPinNot(_errCd, 'error', true, scbPinAppConfig.navLogout(_errCd));
                      error.show();
                    }
                    return ($q.reject(_errCd));
                }).finally(function(error) {
                    return error;
                }));
            },
            extendSession:function (_data){
                scbPinAppConfig.showLoader = true;
                return ($http({
                    method: scbPinAppConfig.webServices['extendSession'].method,
                    url: scbPinAppConfig.webServices['extendSession'].url,
                    withCredentials:true,
                    data:_data,
                    headers: {
                       'Accept': 'application/vnd.api+json'
                    }
                }).then(function(response) {
                    return(response);
                }, function(errResp) {
                    //console.debug(error);
                    var error = new ScbPinNot(errResp.data.errors[0].code, 'error', true, scbPinAppConfig.navLogout(errResp.data.errors[0].code));
                    error.show();
                    return ($q.reject(''+error));
                }).finally(function(error) {
                    return error;
                }));
            },
            invalidateSession:function (_data){
                scbPinAppConfig.showLoader = true;
                var deferred = $q.defer();
                deferred.resolve('redirecting to API Gateway');
                setTimeout(function() {
                    window.location.href = scbPinAppConfig.webServices['invalidateSession'].url + "?killSession=Y";
                }, 5000);
                
                
                return deferred.promise;
                /*
                return ($http({
                    method: scbPinAppConfig.webServices['invalidateSession'].method,
                    url: scbPinAppConfig.webServices['invalidateSession'].url,
                    withCredentials:true,
                    data:_data,
                    headers: {
                       'Accept': 'application/vnd.api+json',
                       "KILL_SESSION": "Y"
                    }
                }).then(function(response) {
                    return(response);
                }, function(errResp) {
                    //console.debug(error);
                  if(errResp.data.errors[0].code === '1702') {
                    window.location = scbPinAppConfig.loginURL;
                  } else {
                    var error = new ScbPinNot(errResp.data.errors[0].code, 'error', true, scbPinAppConfig.navLogout(errResp.data.errors[0].code));
                    error.show();
                  }
                  return ($q.reject(''+error));
                }).finally(function(error) {
                    return error;
                }));
                */
            },
            ssoRedirection:function (_data){
                return ($http({
                    method: scbPinAppConfig.webServices['ssoRequest'].method,
                    url: scbPinAppConfig.webServices['ssoRequest'].url,
                    withCredentials:true,
                    headers: {
                       'Accept': 'application/vnd.api+json'
                    }
                }).then(function(response) {
                    return(response);
                }, function(errResp) {
                    //console.debug(error);
                    var error = new ScbPinNot(errResp.data.errors[0].code, 'error', true, scbPinAppConfig.navLogout(errResp.data.errors[0].code));
                    error.show();
                    return ($q.reject(''+error));
                }));
            }

        }
    }]);
})();
