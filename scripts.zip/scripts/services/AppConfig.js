(function() {

  'use strict';

  angular.module('scbPinApp')
    .service('AppConfig', AppConfig);

  /* @ngInject */
  function AppConfig() {
    this.config = {};
  }

})();
