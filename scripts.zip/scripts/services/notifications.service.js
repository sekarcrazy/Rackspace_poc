(function($) {

    'use strict';

    angular.module('scbPinApp')
        .factory('ScbPinNot', ScbPinNot);

    /* @ngInject */
    function ScbPinNot($rootScope, $timeout,$translate,scbPinAppConfig, $filter, $compile, $interpolate) {

        var that = this;

        that.errorTemplate = '<div class="alert"><a class="error"><div class="icon-infot"></div><p class="sorry">{{\'ALERT_SORRY\' | translate}}</p><p class="error-content">{0}</p></a><a class="close-button"></a></div>';

        that.infoTemplate = '<div class="alert"><a class="info">{0}</a></div>';
        that.warningTemplate = '<div class="alert"><a class="warning">{0}</a></div>';
        that.successTemplate = '<div class="alert"><a class="success">{0}</a></div>';
        that.parentContainer = $('<div id="all-alert"></div>');
        that.bodyContainer = $('body');

        var not = function(messenger, type, avoidDup, isLogout) {
            that.messenger = that.mapErrMsg(messenger)  //default messenger is Hello
            that.type = type || 'error'; //default type is error
            that.avoidDup = avoidDup || false;
            that.isLogout = isLogout||false;

            if ($('#all-alert').length <= 0) {
                that.bodyContainer.append(that.parentContainer);
            }

            that.parentContainer.removeClass('no-bg');
            that.bodyContainer.addClass('disable-body');
        };

        //set error popup
        that.createError = function() {
            this.newTemplate = that.errorTemplate.replace('{0}', '<span>' + that.messenger + '</span>');
            this.newTemplate = $interpolate(this.newTemplate)();
        };
        that.createInfo = function() {
            this.newTemplate = that.infoTemplate.replace('{0}', '<span>' + that.messenger + '</span>');
        };
        that.createWarning = function() {
            this.newTemplate = that.warningTemplate.replace('{0}', '<span>' + that.messenger + '</span>');
        };
        that.createSuccess = function() {
            this.newTemplate = that.successTemplate.replace('{0}', '<span>' + that.messenger + '</span>');
        };
        //destroy the popup
        that.destroy = function(el) {
            el.fadeOut(300, function() {
                $(this).remove();
                that.resetBg();
                if(that.isLogout)scbPinAppConfig.doLogout();
            });
        };

        that.resetBg = function() {
            this.alertCount = that.parentContainer.find('.alert');
            if (this.alertCount.length <= 0) {
                that.parentContainer.addClass('no-bg');
                that.bodyContainer.removeClass('disable-body');
                that.parentContainer.remove();
            }
        };

        that.setNewNot = function() {

            switch (that.type) {
                case 'error':
                    that.createError();
                    break;
                case 'info':
                    that.createInfo();
                    break;
                case 'warning':
                    that.createWarning();
                    break;
                case 'success':
                    that.createSuccess();
                    break;
                default:
            }


            that.elNot = $(this.newTemplate);

            if (that.avoidDup === false) {

                that.parentContainer.append(this.elNot);

            } else {

                that.getCurrentType = $('#all-alert').find('.error');

                if (that.getCurrentType.length === 1) {

                    that.appendErrorLine();

                } else if (that.getCurrentType.length === 0) {

                    that.parentContainer.append(this.elNot);

                }
            }



            return that.elNot;
        };

        that.appendErrorLine = function() {
            that.isAdd = true;
            that.listMess = that.getCurrentType.find('.error-content').find('span');
            for (var i = 0; i < that.listMess.length; i++) {
                that.text = $(that.listMess[i]).text().trim();
                if (that.text === that.messenger) {
                    that.isAdd = false;
                }
            }
            if (that.isAdd) {
                that.getCurrentType.find('.error-content').append('<span>' + that.messenger + '</span>');
            } else {
                console.info('Duplicate messenger!');
            }
        };

        that.initEvent = function(el) {
            el.on('click', function() {

                that.destroy(el);
            });
        };

        //second will close
        not.prototype.show = function(second) {
            that.seconds = second * 1000;
            var el = that.setNewNot();
            that.initEvent(el);
            if (this.seconds) {
                $timeout(function() {
                   that.destroy(el);
                }, that.seconds);
            }
        };

        that.mapErrMsg = function($id){
          switch($id){
            case "1561":
              return  $translate.instant('OTP_EXPIRED',{ errCode: $id });
            case "1563":
              return  $translate.instant('INVALID_OTP',{ errCode: $id });
            case "1572":
            case "1715":
              return  $translate.instant('MAX_RETRY',{ errCode: $id });
            case "1020":
              return  $translate.instant('EMPTY_CARD');
            default:
             return  $translate.instant('GEN_ERR_MSG_TYPE1',{ errCode: $id });
          }
        }


        return not;

    }

})(window.jQuery);
