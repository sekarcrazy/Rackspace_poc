(function() { 'use strict';

 angular.module('scbPinAppConfig', [])

.constant('scbPinAppConfig', {mockTimeoutSec:600,actualTimeoutSec:900,country:{sg:{pinLen:4},vn:{pinLen:6}},webServices:{ssoRequest:{method:'GET',url:'/retail/api/security/v1/ssoRequest?RedirPageId=id'},authorize:{method:'GET',url:'/retail/api/v1/security/ssoAuthorize'},cardList:{method:'GET',url:'/retail/api/products/v1/debitcards?action=ALLOW_PINCHANGE'},generateOTP:{method:'POST',url:'/retail/api/security/v1/generateOTP'},smsReset:{method:'POST',url:'/retail/api/security/v1/pinreset'},extendSession:{method:'GET',url:'/retail/api/security/v1/session'},invalidateSession:{method:'GET',url:'/retail/api/security/v1/ssoRequest',headers:{KILL_SESSION:'Y'}}}})

; })();