(function() {
  'use strict';
  angular.module('scbPinApp').directive('restrictData',
    function() {
      return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl,AppConfig) {
          scope.invalidPin = true;
          function fromUser(text) {
            if (text) {
              var transformedInput = text.toString();
              if(transformedInput.length>2){
                  if(sameNumber(transformedInput) && checkContinuous(transformedInput)){
                      scope.invalidPin = true;
                  }else{
                      scope.invalidPin = false;
                  }
              }
              if(transformedInput.length===1){
                  scope.invalidPin = true;
              }
              if (transformedInput !== text) {
                ngModelCtrl.$setViewValue(transformedInput);
                ngModelCtrl.$render();
              }
              return transformedInput;
            }
            return undefined;
          }

          var sameNumber = function(num){
              var sameNumPattern = /^([0-9])\1*$/g;
              if( num.length>1 && (sameNumPattern.exec(num)!=null)){return false;}
              else{return true;}
          }

          //Check for continous number 1234,2345,3456,..
          var checkContinuous = function(number){
            var stringNumber = number.toString();
            var bool;
            for(var i = 0 ; i < stringNumber.length - 1; i++){
              var value = stringNumber[i];
              var nextValue = stringNumber[i + 1];
              var isContinuous = (nextValue - value) === 1 ? true : false;
              if(!isContinuous){
                bool = true;
                break;
              }
              else{
                bool = false;
              }
            }
            return bool;
          }
          ngModelCtrl.$parsers.push(fromUser);
        }
      };
    });
})();
