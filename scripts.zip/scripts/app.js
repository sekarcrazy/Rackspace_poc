'use strict';

/**
 * @ngdoc overview
 * @name scbPinApp
 * @description
 * # scbPinApp
 *
 * Main module of the application.
 */
angular
  .module('scbPinApp', [
    'ui.router',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'scbPinAppConfig',
    'scbAuthSSCode',
    'ngDialog',
    'pascalprecht.translate'
  ])
  .config(function ($routeProvider,scbPinAppConfig,$stateProvider,$provide, $locationProvider,$urlRouterProvider,$translateProvider) {
    $locationProvider.html5Mode(true);
    $urlRouterProvider.otherwise('/');
    var redirectUrl = '/pin-change.html?:lang/:ctry/:seg/:sapp/:userData/:RedirPageId';
    if (scbPinAppConfig.env && scbPinAppConfig.evn === 'development') {
      redirectUrl = '/';
    }

    $stateProvider
    /*.state('home', {
      url: '/?code',
      template: '',
      controller: 'AuthCtrl'
    })*/
    .state('managePin', {
      url: redirectUrl,
      templateUrl: 'scripts/templates/main.html',
      controller:'managePinController'
    })
    $translateProvider.useSanitizeValueStrategy(null);

    $translateProvider.useStaticFilesLoader({
      prefix: 'resources/locale_',
      suffix: '.json'
    });

  
    $translateProvider.registerAvailableLanguageKeys(['en', 'vi'], {
      'en-US': 'en',
      'vi-VN': 'vi'
    });
    //$translateProvider.preferredLanguage('vi');
    $translateProvider.fallbackLanguage('en');
    //$translateProvider.useLocalStorage();

  });
