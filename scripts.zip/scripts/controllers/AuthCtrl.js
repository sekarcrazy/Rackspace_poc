(function () {

  'use strict';

  angular
    .module('scbAuthSSCode',[])
    .controller('AuthCtrl', authBySSCode)


  /* @ngInject */
  function authBySSCode($stateParams, $state, $http,scbPinAppConfig) {
    console.log("params", $stateParams.code);
    var params=  {
        SSCode: $stateParams.code
    }
    var formConfigUrl =scbPinAppConfig.webServices['authorize'].url+"?SSCode="+$stateParams.code;
     $http({method: 'get', url: formConfigUrl, withCredentials: true})
      .then(function(response) {
        console.log("SSO SUCCESS");
        window.location = "/index.html?lang=en&ctry=sg&sapp=NFS&availablecard=B"
        //$state.go('managePin');
      }, function(data) {
        $state.go('managePin');
        console.log("SSO FAILED"+data.status);
      });
  }


})();
