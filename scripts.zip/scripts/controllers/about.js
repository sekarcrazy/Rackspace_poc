'use strict';

/**
 * @ngdoc function
 * @name scbPinApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the scbPinApp
 */
angular.module('scbPinApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
