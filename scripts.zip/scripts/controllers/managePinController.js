(function() {
    'use strict';
    angular
        .module('scbPinApp')
        .controller('managePinController', managePinCtlr)

    function managePinCtlr($scope, $timeout, cardsListService, scbPinAppConfig, AppConfig, serviceTimeout, ngDialog, ScbPinNot, $stateParams, $translate) {
        $(function() {
            $('input').on('focus', function() {
                if ($(this).attr('placeholder')) $(this).data('placeholder', $(this).attr('placeholder')).removeAttr('placeholder');
            }).on('blur', function() {
                if ($(this).data('placeholder')) $(this).attr('placeholder', $(this).data('placeholder')).removeData('placeholder');
            });
        });
        $(document).ready(function() {
            $timeout(function() {
              $('.tooltipCustom').tooltipster({
                delay: 200,
                contentAsHTML: true,
                interactive: true,
                maxWidth: 300
              });
            });

            $('input[type="tel"]').keydown(function(e) {
               if(e.keyCode === 9){
                  return true;
               }
                if(!((e.keyCode > 95 && e.keyCode < 106) || (e.keyCode > 47 && e.keyCode < 58) || e.keyCode == 8)) {
                    return false;
                }
            });


        });
        init();
        var logoutErrCode = ['1021','1022','1020','0008','0009','0010','0014','1572','1700','1701','1702','1703','1704','1705','1706','1708','1710','1720','1713','1711','1714','1715','13043'];
        var erroStatus='';
        function init() {
            AppConfig.config.ctry = ($stateParams.ctry != null) ? ($stateParams.ctry).toLowerCase() : 'vn';
            AppConfig.config.lang = $stateParams.lang || 'en';
            AppConfig.config.sapp = ($stateParams.sapp).toLowerCase();
            AppConfig.config.userdata = $stateParams.userdata;
            $translate.use(AppConfig.config.lang);

            var isIE = !!navigator.userAgent.match(/Trident/g) || !!navigator.userAgent.match(/MSIE/g);
            var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
            if(isIE || isFirefox){
              $('#enterPinField').attr("type","password");
              $('#reEnterPinField').attr("type","password");
              $('#otpField').attr("type","password");
            }
            
        }
        var resetAllFields = function() {
            $scope.dispCard = [];
            $scope.currentPage = 1;
            $scope.showError = false;
            $scope.enterPin = '';
            $scope.reEnterPin = '';
            $scope.enterOTP = '';
            $scope.refNum = '';
            $scope.showInputFields = false;
            $scope.pleaseSelectCard = false;
            $scope.pinsDoNotMatch = false;
            $scope.reEnterErr = false;
            $scope.maxLen = scbPinAppConfig.country[AppConfig.config.ctry].pinLen;
            $scope.otpPrefix = 'XXXXXXXXX';
            $scope.isEnableNxt = false;
            $scope.disableNxt = true;
            $scope.cardType = "Debit";
            $scope.otpNote = "";
            AppConfig.config.selCard = '';
            $scope.showCardSel = false;
            $scope.disableRetryOTP = false;
            $('#enterPinField').attr('maxlength', scbPinAppConfig.country[AppConfig.config.ctry].pinLen);
            $('#reEnterPinField').attr('maxlength', scbPinAppConfig.country[AppConfig.config.ctry].pinLen);
            $("#step2NxtBtn").removeClass("default").addClass("disabled");
            $scope.resentOtpCnt = 0;
            $scope.loginURL = scbPinAppConfig.country[AppConfig.config.ctry][AppConfig.config.sapp]+"&preflanguage="+AppConfig.config.lang;
            scbPinAppConfig.loginURL = $scope.loginURL; // Duplicate to use this URL in seriveTimeout factory
            $scope.resetFail  = false;
            $scope.loader = false;
            $scope.disableReEnter= true;
            $scope.showRef = true;
            $timeout(function() {
               $translate('NEXT_HOVER').then(function (value) {
                 $('#step1_nxt_btn').tooltipster('content', value);
                });
            }, 500);

        };

        //$( document ).tooltip({});

        resetAllFields();

        var getCardsData = function() {
            $scope.loader = true;
            cardsListService.getCardsList()
                .then(function(data) {
                    $scope.loader = false;
                    $scope.cardList = [];
                    $scope.showCardSel = true;
                    serviceTimeout.startTimer();
                    var appendedCardList = data.included;
                    _.each(appendedCardList, function(card, i) {
                        var cardObj = card.attributes;
                        if (cardObj.cardType) {
                            $scope.dispCard[i] = cardObj.displayCardValue;
                            $scope.cardList[cardObj.displayCardValue] = (cardObj);
                        } else {
                            $scope.keyInfo = cardObj.base64Challenge;
                            $scope.keyInfo = {
                                base64Challenge: cardObj.base64Challenge,
                                modulus: cardObj.modulus,
                                exponent: cardObj.exponent,
                                keyIndex: cardObj.keyIndex

                            }
                        }
                    });
                },function(){
                    $scope.loader = false;
                });
        };

        $scope.generateOTP = function() {
          $scope.loader = true;
          if($scope.resentOtpCnt>1){
                $scope.otpNote = $translate.instant('NOTE_OTP_LAST');
                $scope.showOTPBtn = true;
                $scope.disableRetryOTP = true;
            }else{
                $scope.showOTPBtn = false;
            }
            $scope.enterOTP = '';
            var pinToEncrypt = (AppConfig.config.selCard.cardNumber + "_-_" + 1111 + "_-_" + $scope.enterPin + "_-_" + $scope.reEnterPin + "_-_" + AppConfig.config.selCard.cardExpiry + "_-_" + $scope.keyInfo.base64Challenge);
            var cardToEncrypt = (AppConfig.config.selCard.cardNumber + "_-_" + 20140202 + "_-_" + AppConfig.config.selCard.cardExpiry + "_-_" + 173 + "_-_" + 'N3168828Q' + "_-_" + AppConfig.config.selCard.cardEmbossedName + "_-_" + 786 + "_-_" + $scope.keyInfo.base64Challenge);
            var _encCardPin = hex2b64(rsaEncrypt($scope.keyInfo.exponent, $scope.keyInfo.modulus, pinToEncrypt));
            var _encCardInfo = hex2b64(rsaEncrypt($scope.keyInfo.exponent, $scope.keyInfo.modulus, cardToEncrypt));
            $scope.newpin = ('XXXXXXXXXX').substring(0, scbPinAppConfig.country[AppConfig.config.ctry].pinLen);
            var postBody = {
                "data": {
                    "type": "generateotp",
                    "id": new Date().getTime(),
                    "attributes": {
                        "functionId": "PINCHANGE",
                        "cardType": "DEBIT",
                        "cardSequenceNumber": AppConfig.config.selCard.cardSequenceNumber,
                        "encCardPin": _encCardPin,
                        "encCardInfo": _encCardInfo,
                        "pinKeyIndex": $scope.keyInfo.keyIndex,
                        "index": AppConfig.config.selCard.index
                    },
                    "relationships": {}
                },
                "included": []
            }
            cardsListService.submitOTP(postBody)
                .then(function(data) {
                    $scope.loader = false;
                    $scope.otpPrefix = data.otpPrefix + "-";
                    $scope.otpSn = data.otpSn;
                    $scope.goToPage(2);
                },function(){
                    $scope.loader = false;
                });


        }

        $scope.smsReset = function() {
            $scope.loader = true;
            var otpToEncrypt = ($scope.enterOTP + "_-_" + $scope.keyInfo.base64Challenge);
            var _encOtp = hex2b64(rsaEncrypt($scope.keyInfo.exponent, $scope.keyInfo.modulus, otpToEncrypt));
            var postBody = {
                "data": {
                    "type": "smsotp",
                    "id": new Date().getTime(),
                    "attributes": {
                        "otpSn": $scope.otpSn,
                        "encOtp": _encOtp,
                        "otpKeyIndex": $scope.keyInfo.keyIndex
                    },
                    "relationships": {}
                },
                "included": []
            }
           cardsListService.resetBySMS(postBody)
            .then(function(data) {
                $scope.loader = false;
                $scope.showRef = true;
                $scope.refNum = data.receiptNumber;
                $scope.enterOTP = '';
                if(data.errorCd!=null && (data.errorCd=="1505" || data.errorCd=="1507")){
                    $scope.resetFail = true;
                    $scope.ackMsg = $translate.instant('GEN_ERR_MSG_TYPE1',{ errCode: data.errorCd });
                    console.log("200 ERROR = "+$scope.ackMsg);
                    $scope.goToPage(3);
                }else if($scope.refNum!=null){
                    $scope.ackMsg = $translate.instant('MSG_SUCCESS');
                    console.log("SUCCESS = "+$scope.ackMsg);
                    $scope.goToPage(3);
                }
            },function(_err){
              $scope.loader = false;
              $scope.showRef = false;
              $scope.enterOTP = '';
              if(_err=="1508"||_err=="1509"||_err=="0014"){
                  $scope.ackMsg = $translate.instant('GEN_ERR_MSG_TYPE1',{ errCode: _err });
                  console.log("ERROR 400 = "+$scope.ackMsg);
                  $scope.resetFail = true;
                  $scope.goToPage(3);
              }else if(_err=="0010"||_err=="0008"){
                  $scope.ackMsg = $translate.instant('GEN_ERR_MSG_TYPE2',{ errCode: _err });
                  console.log("ERROR 500 = "+$scope.ackMsg);
                  $scope.resetFail = true;
                  $scope.goToPage(3);
              }

            });
        }

        $scope.changedValue = function(card) {
            $scope.disableNxt = true;
            $scope.showError = false;
            $scope.pinsDoNotMatch = false;
            $scope.pleaseSelectCard = false;
            $scope.selectedCard = card;
            $scope.showInputFields = $scope.selectedCard;
            $scope.enterPin = '';
            $scope.reEnterPin = '';
            AppConfig.config.selCard = $scope.cardList[card];
        };

        $scope.validatePin = function() {
            return ($scope.enterPin.toString() === $scope.reEnterPin.toString())
        };

        $scope.validateFields = function($event) {
            $timeout(function() {
               if ($scope.enterPin.length!=0 && $scope.reEnterPin != undefined && ($scope.reEnterPin.toString().length === scbPinAppConfig.country[AppConfig.config.ctry].pinLen)) {
                    if ($scope.enterPin && $scope.reEnterPin && !$scope.validatePin()) {
                        $scope.pinsDoNotMatch = true;
                        $scope.disableNxt = true;
                    } else {
                        $scope.pinsDoNotMatch = false;
                        $scope.disableNxt = false;
                    }
                } else {
                    $scope.pinsDoNotMatch = false;
                    $scope.disableNxt = true;
                }

            }, 100);
        };
        $scope.goToPage = function(pageNo) {
            switch (pageNo) {
                case 1:
                    {
                        $scope.currentPage = pageNo;
                        $scope.enterPin = $scope.reEnterPin = '';
                        $scope.showError = false;
                        $("#Step1NxtBtn").removeClass("default").addClass("disabled");
                        $("#step2NxtBtn").removeClass("default").addClass("disabled");
                    }
                    break;
                case 2:
                    {
                        //check for empty fields on page 1

                        if ($scope.enterPin && $scope.reEnterPin && $scope.validatePin()) {
                            $scope.currentPage = pageNo;
                            $scope.showError = false;
                            // calculate 30 seconds
                            $timeout(function() {
                                $scope.resentOtpCnt++;
                                if ($scope.resentOtpCnt < 3){
                                    $scope.otpNote = $translate.instant('NOTE_OTP_FIRST');
                                    $scope.showOTPBtn = true;
                                }
                            }, 30000);
                        } else if (!$scope.selectedCard) {
                            $scope.pleaseSelectCard = true;
                            $scope.showError = false;
                            $scope.pinsDoNotMatch = false;
                        } else if ($scope.enterPin && $scope.reEnterPin && !$scope.validatePin()) {
                            $scope.pinsDoNotMatch = true;
                            $scope.showError = false;
                            $scope.pleaseSelectCard = false;
                        } else {
                            $scope.showError = true;
                            $scope.pleaseSelectCard = false;
                            $scope.pinsDoNotMatch = false;
                        }
                    }
                    break;
                case 3:
                    {
                        $scope.currentPage = pageNo;
                    }
                    break;
                case 'finish':
                    {
                        resetAllFields();
                        $("input[type=radio][name=cardTypeGroup]").prop("checked", false);
                        getCardsData();
                        $scope.currentPage = 1;

                    }
                    break;
            }
        };
        $scope.pinResetEvent = function() {
            //$scope.pinsDoNotMatch = false;
            $scope.reEnterPin = null;
            $scope.disableReEnter = true;
            $("#Step1NxtBtn").removeClass("default").addClass("disabled");
            if($scope.invalidPin && $scope.enterPin!=null &&$scope.enterPin.length == $scope.maxLen){
                $scope.disableReEnter = false;
            }
        }

        $scope.pinFieldEvent = function() {
            if ($scope.reEnterPin != null && $scope.reEnterPin.length > $scope.maxLen) {
                $scope.reEnterPin = parseInt($scope.reEnterPin.substring(0, $scope.maxLen));
            }
        }

        $scope.$watch('disableNxt', function(newVal) {
            if (newVal) {
                $("#Step1NxtBtn").removeClass("default").addClass("disabled");
            } else {
                $("#Step1NxtBtn").removeClass("disabled").addClass("default");
            }
        });

        $scope.otpChngEvent = function() {
            if ($scope.enterOTP != null && $scope.enterOTP.length > 5) {
                $("#step2NxtBtn").removeClass("disabled").addClass("default");
            } else {
                $("#step2NxtBtn").removeClass("default").addClass("disabled");
            }
            if ($scope.enterOTP && $scope.enterOTP.length > 6) {
                $scope.enterOTP = parseInt($scope.enterOTP.substring(0, 6));

            }
        }


        $scope.showTimeout = function() {
            ngDialog.open({
                template: 'scripts/templates/modal/timeout.html',
                className: 'ngdialog-theme-default',
                scope: $scope,
                showClose: false,
                closeByDocument: false
            });
        };

        serviceTimeout.timeoutParentFun = $scope.showTimeout;
        $scope.continueSession = function() {
          $scope.loader = true;
          cardsListService.extendSession()
            .then(function(data) {
              ngDialog.close();
               $scope.loader = false;
              serviceTimeout.startTimer();
            });
        }
        $scope.exitWindow = function() {
            $scope.loader = true;
            cardsListService.invalidateSession()
            .then(function(data) {
              ngDialog.close();
              //window.location = $scope.loginURL;
            });
        };
        $scope.toggleDateInput = function(_type) {
            resetAllFields();
            $scope.cardType = _type;
            getCardsData();
        }
        getCardsData();
        $scope.closeEvent = function() {
            ngDialog.open({
                template: 'scripts/templates/modal/close.html',
                className: 'ngdialog-theme-default',
                scope: $scope
            });
        }
        $scope.continue = function() {
            ngDialog.close();
        }
        $scope.exit = function() {
            ngDialog.close();
            window.location = scbPinAppConfig.webServices['ssoRequest'].url;
        }

        scbPinAppConfig.navLogout = function(errCode){
            var bool = false;
            erroStatus = errCode;
            _.each(logoutErrCode,function(val){
              if(val==errCode){
                bool = true;
              }
            })
            return bool;
        }

        scbPinAppConfig.doLogout = function(){
            $scope.loader = true;
            console.log("erroStatus ",erroStatus);
            if(erroStatus === '1702') 
              cardsListService.invalidateSession();
            else
              window.location.href = scbPinAppConfig.webServices['ssoRequest'].url;
        }
    };



})();
