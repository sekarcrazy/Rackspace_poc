'use strict';

/**
 * @ngdoc function
 * @name scbPinApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the scbPinApp
 */
angular.module('scbPinApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
