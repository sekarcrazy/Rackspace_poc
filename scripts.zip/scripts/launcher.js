/* jshint jquery: true */
(function($) {

'use strict';

$.fn.cipLauncher = function(options) {
  this.each(function() {
      $(this).click(function(e) {
        e.preventDefault();
        launch($(this).attr('href'));
      });
  });

  function launch(cipUrl) {
    var tokenUrl = options.apiUrl + '/' + options.tokenEndPoint,
      authUrl = options.apiUrl + '/' + options.authEndPoint;

    var t=window.location.href.split('?')[1];
        t = t ? t.split('token=')[1] : options.signonToken;
    $.ajax({
        url: tokenUrl,
        method: 'GET',
        beforeSend: function(request){
          request.setRequestHeader("SIGNON_TOKEN", t);
        }
      })
      .done(function(data, textStatus, jqXHR) {
        console.log("success");
        console.debug(data.ssoCode);
        // Redirect the applicaton and pass the code along.
        window.location.replace(cipUrl + '?code=' + data.ssoCode);
        //console.log(cipUrl + '?code=' + data.ssoCode);
      })
      .fail(function(jqXHR, textStatus, errorThrown) {
        // @todo Something if call failed.
        alert('Token failed');
      });
  }
};

})(jQuery);
